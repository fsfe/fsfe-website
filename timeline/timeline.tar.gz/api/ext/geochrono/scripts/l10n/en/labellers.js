/*==================================================
 *  Localization of Geochrono Labeller
 *==================================================
 */

Timeline.GeochronoLabeller.eonNames["en"]       = Timeline.Geochrono.eons;
Timeline.GeochronoLabeller.eraNames["en"]       = Timeline.Geochrono.eras;
Timeline.GeochronoLabeller.periodNames["en"]    = Timeline.Geochrono.periods;
Timeline.GeochronoLabeller.epochNames["en"]     = Timeline.Geochrono.epoches;
Timeline.GeochronoLabeller.ageNames["en"]       = Timeline.Geochrono.ages;
