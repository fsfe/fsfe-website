/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["se"] = {
    wikiLinkLabel:  "Discuss"
};

